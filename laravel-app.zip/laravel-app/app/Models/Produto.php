<?php

namespace App\Models;


use App\Models\Cliente;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Produto extends Model
{
     use HasFactory;

     protected $fillable = [    
          'codigo',
          'descricao',
          'preco',
          'imposto',
          ];

          public function clientes()
          {
            return $this->belongsTo(Cliente::class);
          }
          

          public function getValorImpostoAttribute()
          {
          return $this->preco * $this->imposto / 75;
          } 
       
}



/* public function clientes()
{
    return $this->belongsToMany(Cliente::class, 'associacoes');
}

public function getValorImpostoAttribute()
{


return $this->preco * $this->imposto / 100;
} */