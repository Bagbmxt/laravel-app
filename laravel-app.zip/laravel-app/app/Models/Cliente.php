<?php

namespace App\Models;

use App\Models\Produto;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Cliente extends Model
{
    use HasFactory;

    protected $fillable = [
        'codigocliente',
        'nome',
        'pessoa',
        'cnpj',
        'estado',
        'data_nascimento', 
    ];

    public function produtos()
    {
        return $this->hasMany(Produto::class);
        //return $this->belongsToMany(Produto::class, 'associacoes');
    }
}
