<?php

namespace App\Http\Controllers;


 use App\Models\{
    Produto,
    Cliente

}; 
//use App\Models\Produto;

use Illuminate\Http\Request;

class ProdutosController extends Controller
{
     protected $produtos;
     protected $clientes;
 

    public function __construct(Produto $produtos, Cliente $clientes)
    {
        $this->produtos = $produtos;
        $this->clientes = $clientes;
      
    } 


    public function index($clienteId)
    {

        if( !$clientes = $this->clientes->find($clienteId)) {
            return redirect()->back();
           }
    
           $produtos = $clientes->produtos()->get();
    
            return view('clientes.produtos.index', compact('cliente', 'produtos'));

     /*   $produtos = Produto::all();
        return view('produtos.index', ['produtos' => $produtos]); */
    }

    public function create()
    {
        return view('produtos.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        Produto::create($request->all());
        return redirect()->route('produtos.index');
     

    }

    public function show(int $id)
    {

         //$user = User::where('id', $id)->first();
         if(!$produtos = Produto::find($id))
         return redirect()->route('produtos.index');
    
         return view('produtos.show', compact('produtos'));   
    }

    public function edit($id)
    {
        if(!$produtos = Produto::find($id))
        return redirect()->route('produtos.index');
    
        return view('produtos.edit', compact('produtos'));
    }

    public function update(Request $request, string $id)
    {
        if(!$produtos = Produto::find($id))
        return redirect()->route('produtos.index');
    
        $data = $request->all();

    
        $produtos->update($data);
        
        return redirect()->route('produtos.index');
    }

    public function destroy(string $id)
    {

        $produtos = Produto::find($id);
        $produtos->delete();
        return redirect()->back();
    }

}