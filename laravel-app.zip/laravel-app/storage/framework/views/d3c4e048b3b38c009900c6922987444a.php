  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 


    <main class="container" style="margin-top:20px ">
   
        <a  type="button" href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary" > NOVO CLIENTE</a>
        <a style="margin-left: 20px" href="/" class="btn btn-success">Voltar</a> 
      
    
      <div class="container" style="margin-top: 100px;">
      <h1 style="color: blue" > Clientes Início  </h1>

        <table class="table" >
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">CodigoCliente</th>
                <th scope="col">nome</th>
                 <th scope="col">pessoa</th>
                <th scope="col">cnpj</th>
                <th scope="col">estado</th>
                <th scope="col">DataNascimento</th> 
                <th scope="col">Produtos</th>
                <th scope="col">Ver</th>
                <th scope="col">Editar</th>
                 <th scope="col">Deletar</th>
              </tr>
            </thead>
            <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($cliente->id); ?></th>
                <td><?php echo e($cliente->codigocliente); ?></td>
                <td><?php echo e($cliente->nome); ?></td>
                <td><?php echo e($cliente->pessoa); ?></td>
                <td><?php echo e($cliente->cnpj); ?></td>
                <td><?php echo e($cliente->estado); ?></td>
                <td><?php echo e($cliente->data_nascimento); ?></td> 

              <td>
                <a type="button" href="<?php echo e(route ('produtos.index', $cliente->id)); ?>" class="btn btn-success">PRODUTOS </a>
              </td>
              
                <td>
                    <a type="button" href="<?php echo e(route('clientes.show', $cliente->id)); ?>" class="btn btn-success">VER </a>
                </td>
                <td>
                    <a type="button" href="<?php echo e(route('clientes.edit', $cliente->id)); ?>" class="btn btn-warning">EDITAR </a>
                </td>
                <td>
            <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="post">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit"  class="btn btn-danger">DELETAR </a>
            </form>
                </td>
              </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
    </main>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/clientes/index.blade.php ENDPATH**/ ?>