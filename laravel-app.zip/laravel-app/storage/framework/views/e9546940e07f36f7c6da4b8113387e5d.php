  
<?php $__env->startSection('content'); ?>


  <?php echo $__env->yieldContent('body'); ?>

    <main class="container">
        <h1>Adicionar JOGOS</h1>
      <form action="<?php echo e(route('jogos-store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <label for="name">Nome</label>
              <input type="text"  class="form-control" name="nome"placeholder="Digite um nome" >
            </div>

            <div class="form-group">
              <label for="categoria">categoria</label>
              <input type="text"  class="form-control" name="categoria"placeholder="Digite uma categoria" >
            </div>

            <div class="form-group">
              <label for="ano_criacao">Ano</label>
              <input type="text"  class="form-control" name="ano_criacao"placeholder="Digite um Ano" >
            </div>

            <div class="form-group">
              <label for="valor">Valor</label>
              <input type="number"  class="form-control" name="valor"placeholder="Digite umValor" >
            </div>

            <button type="submit"  name="submit" class="btn btn-primary">ADICIONAR</button>
          </form>
    </main>

    <?php $__env->stopSection(); ?>












<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/jogos/create.blade.php ENDPATH**/ ?>