  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 


    <main class="container">
        <h1>Adicionar</h1>
        <form method="post" action="<?php echo e(route('user.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
              <label for="name" class="form-label">Nome</label>
              <input type="text"  class="form-control" name="name" id="name" aria-describedby="emailHelp">

            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input type="email" name="email" class="form-control" id="email">
            </div>

            <div class="mb-3">
              <label for="email" class="form-label">SENHA</label>
              <input type="password" name="password" class="form-control" id="password">
            </div>
            
            <button type="submit" class="btn btn-primary">Cadastrar</button>   
            <a href="/" class="btn btn-success" role="button">Voltar</a>
            
          </form>
    </main>
 
   <?php $__env->stopSection(); ?> 












<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/user/create.blade.php ENDPATH**/ ?>