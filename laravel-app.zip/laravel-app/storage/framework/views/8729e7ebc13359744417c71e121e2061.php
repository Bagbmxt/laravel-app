  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 

 <main class="container" style="margin-top:20px ">
   
  <a  type="button" href="<?php echo e(route('produtos.create')); ?>" class="btn btn-primary" > NOVO PRODUTO</a>
  <a style="margin-left: 20px" href="/produtos" class="btn btn-success">Voltar</a> 


<div class="container" style="margin-top: 100px;">
<div class="cor" style="color: blue" > Produtos Visualizar  

        <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Codigo</th>
                <th scope="col">Descrição</th>
                <th scope="col">Preço</th>
                <th scope="col">Imposto</th>


              </tr>
            </thead>
            <tbody>

              <tr>
                <th scope="row"><?php echo e($produtos->id); ?></th>
                <td><?php echo e($produtos->codigo); ?></td>
                <td><?php echo e($produtos->descricao); ?></td>
                <td><?php echo e($produtos->preco); ?></td>
                <td><?php echo e($produtos->imposto); ?></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/produtos/show.blade.php ENDPATH**/ ?>