  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 

 <a style="margin-left: 20px" href="/produtos" class="btn btn-success">Voltar</a>
 <h1 style="color: rgb(0, 0, 0)" >Produtos Editar  </h1>
 
<div style="background-color: rgb(86, 102, 80)">
 <main class="container" style="margin-top:20px" >

  



<div class="container" style="margin-top: 100px;">
        <h1>Atualizar Produto</h1>
        <form method="post" action="<?php echo e(route('produtos.update', $produto->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3" style="width: 7%">
              <label for="codigo"  class="form-label">Codigo</label>
              <input type="text"  class="form-control" value="<?php echo e($produto->codigo); ?>"   name="codigo" placeholder="Codigo :">
            </div>
          
            <div class="mb-3" style="width: 50%">
              <label for="descricao" class="form-label">Descrição</label>
              <input type="text"  class="form-control" value="<?php echo e($produto->descricao); ?>" name="descricao"  placeholder="Descricao:">
            </div>
               
            <div class="mb-3"style="width: 7%">
              <label for="preco" class="form-label">Preço</label>
              <input type="text"  class="form-control" value="<?php echo e($produto->preco); ?>" name="preco" placeholder="Preço:">
            </div>
          
            <div class="mb-3"style="width: 8%">
              <label for="imposto" class="form-label">Imposto</label>
              <input type="text" class="form-control" value="<?php echo e($produto->imposto); ?>" name="imposto" placeholder="Imposto :">
            </div>  
          
              <button type="submit" class="btn btn-primary">Cadastrar</button>   
              <a href="/" class="btn btn-success" role="button">Voltar</a>
          </form>

    </main>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/clientes/produtos/edit.blade.php ENDPATH**/ ?>