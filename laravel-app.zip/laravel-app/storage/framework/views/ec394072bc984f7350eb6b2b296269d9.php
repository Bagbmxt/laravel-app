  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?>  



    <main class="container mt-5">
      <div class="row">
        <div class="col-sm-6">
          <h1>Index</h1>
        </div>
<div class="col-sm-6">
  <a href="<?php echo e(route('jogos-create')); ?>" class="btn btn-success">Novo jogo</a>
</div>
      </div>
    
    
            NOVO JOGO
        </a>
        <table class="table mt-3">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">categoria</th>
                <th scope="col">ano de criacao</th>
                <th scope="col">valor</th>
                <th scope="col">Botao</th>
                <th scope="col">Editar</th>
                 <th scope="col">Deletar</th>
              </tr>
            </thead>
            <tbody>
        <?php $__currentLoopData = $jogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jogo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($jogo->id); ?></th>
                <td><?php echo e($jogo->nome); ?></td>
                <td><?php echo e($jogo ->categoria); ?></td>
                <td><?php echo e($jogo->year); ?></td>
                <td><?php echo e($jogo->valor); ?></td>                 
                <td>
             
            </form>
                </td>
              </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </main>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/jogos/index.blade.php ENDPATH**/ ?>