<header>

</header><?php /**PATH C:\laragon\www\laravel-app\resources\views/layout/header.blade.php ENDPATH**/ ?>