
<?php /**PATH C:\laragon\www\laravel-app\vendor\filament\filament\src\/../resources/views/components/layouts/app/sidebar/footer.blade.php ENDPATH**/ ?>