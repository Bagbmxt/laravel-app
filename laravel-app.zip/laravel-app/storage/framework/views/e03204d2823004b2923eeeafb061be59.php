  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 


    <main class="container" style="margin-top:20px ">
   
        <a  type="button" href="<?php echo e(route('user.create')); ?>" class="btn btn-primary" > NOVO USUARIO</a>
        <a style="margin-left: 20px" href="/" class="btn btn-success">Voltar</a> 
      
    
      <div class="container" style="margin-top: 100px;">
      <h1 style="color: blue" > Usuários Início  </h1>

        <table class="table" >
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Email</th>
                <th scope="col">Botao</th>
                <th scope="col">Editar</th>
                 <th scope="col">Deletar</th>
              </tr>
            </thead>
            <tbody>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($user->id); ?></th>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <a type="button" href="<?php echo e(route('user.show', $user->id)); ?>" class="btn btn-success">VER </a>
                </td>
                <td>
                    <a type="button" href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-warning">EDITAR </a>
                </td>
                <td>
            <form action="<?php echo e(route('user.destroy', $user->id)); ?>" method="post">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit"  class="btn btn-danger">DELETAR </a>
            </form>
                </td>
              </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
    </main>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/user/index.blade.php ENDPATH**/ ?>