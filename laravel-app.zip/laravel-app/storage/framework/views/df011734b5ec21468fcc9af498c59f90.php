  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 


    <main class="container">
        <h1>Adicionar Clientes</h1>
        <form method="post" action="<?php echo e(route('clientes.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
              <label for="codigocliente" class="form-label">Codigocliente</label>
              <input type="text"  class="form-control"  name="codigocliente" placeholder="Codigo Cliente:">
            </div>

            <div class="mb-3">
              <label for="nome" class="form-label">Nome</label>
              <input type="text" name="nome" class="form-control"  placeholder="Nome:">
            </div>
             
            <input type="radio" id="" name="pessoa" value="J">
            <label for="pessoa">fisico</label><br>
            <input type="radio" id="pessoa" name="pessoa" value="F">
            <label for="pessoa">Juridico</label><br>
            <input type="radio" id="pessoa" name="pessoa" value="O">
            <label for="pessoa">Outros</label>
            
            <div class="mb-3">
              <label for="cnpj" class="form-label">CNPJ</label>
              <input type="text" name="cnpj" class="form-control" placeholder="CNPJ:">
            </div>

           <div class="mb-3">
              <label for="estado" class="form-label">Estado</label>
              <input type="text" name="estado" class="form-control" placeholder="Estado:">
            </div>  

            <div class="mb-3">
              <label for="data_nascimento" class="form-label">Data De Nascimento</label>
              <input type="date" name="data_nascimento" class="form-control" placeholder="Data de Nascimento:">
            </div>
 
            
            <button type="submit" class="btn btn-primary">Cadastrar</button>   
            <a href="/" class="btn btn-success" role="button">Voltar</a>
            
          </form>
    </main>
 
   <?php $__env->stopSection(); ?> 












<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/clientes/create.blade.php ENDPATH**/ ?>