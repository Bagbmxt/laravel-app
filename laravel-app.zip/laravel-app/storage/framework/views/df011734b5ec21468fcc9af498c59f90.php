<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Clientes Início</title>
</head>

<body class="body-clientes-index">
    <header>
        <nav class="nav-bar">
            <div class="logo">
                <h1>Logo</h1>
            </div>
            <div class="nav-list">
                <ul>
                    <li class="nav-item"><a href="clientes/create" class="nav-link">Novo Cliente</a></li>
                    <li class="nav-item"><a href="clientes" class="nav-link">Listar Clientes</a></li>
                    <li class="nav-item"><a href="/" class="nav-link"> Home</a></li>
                </ul>
            </div>
            <div class="login-button">
                <button><a href="#">Entrar</a></button>
            </div>

            <div class="mobile-menu-icon">
                <button onclick="menuShow()"><img class="icon" src="img/menu_white_36dp.svg" alt=""></button>
            </div>
        </nav>
        <div class="mobile-menu">
            <ul>
              <li class="nav-item"><a href="clientes/create" class="nav-link">Novo Cliente</a></li>
              <li class="nav-item"><a href="clientes" class="nav-link">Listar Clientes</a></li>
              <li class="nav-item"><a href="/" class="nav-link"> Home</a></li>
            </ul>

            <div class="login-button">
                <button><a href="#">Entrar</a></button>
            </div>
        </div>
    </header>
    
    <div class="alert alert-primary" role="alert">
      <?php if($errors->any()): ?>
    <ul class="errors">
     
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            
              <li class="error"> <?php echo e($error); ?></li>
         </ul>
    </div>
    <?php endif; ?> 

    <main class="container">
        <h1>Adicionar Clientes</h1>

 
        
   
        <form method="post" action="<?php echo e(route('clientes.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3 "  style="width: 30%">
             <b> <label for="codigocliente" class="form-label">Codigocliente</label></b>
              <input type="text"  class="form-control" name="codigocliente" placeholder="Codigo Cliente:" value="<?php echo e(old('codigocliente')); ?>">
            </div>

            <div class="mb-3"style="width: 40%">
              <b>   <label for="nome" class="form-label">Nome</label></b>
              <input type="text" name="nome" class="form-control"  placeholder="Nome:" value="<?php echo e(old('nome')); ?>">
            </div>

            <div class="mb-3" style="width: 30%">
              <b>  <label for="nome" class="form-label">Pessoa</label><br></b>
            <input type="radio" name="pessoa" value="J" <?php echo e(old('pessoa') == 'J' ? 'checked' : ''); ?> > 
            <b>  <label for="pessoa">Pessoa Jurídica</label><br></b>

            <input type="radio" name="pessoa" value="F" <?php echo e(old('pessoa') == 'F' ? 'checked' : ''); ?>> 
            <b>   <label for="pessoa">Pessoa Física</label><br></b>

            <input type="radio" name="pessoa" value="O" <?php echo e(old('pessoa') == 'O' ? 'checked' : ''); ?>>
            <b>  <label for="pessoa">Outros</label></b>
             </div>

            <div class="mb-3" style="width: 30%">
              <b>   <label for="cnpj" class="form-label">CNPJ</label></b>
              <input type="text" name="cnpj" class="form-control" placeholder="CNPJ:" value="<?php echo e(old('cnpj')); ?>">
            </div>
           
            <b>   <label for="estado"  >Estado</label></b>
            <select style="width: 10%" id="estado" name="estado">
              <option value="SP">SP</option>
              <option value="PB">MG </option>
              <option value="PB">SC</option>
              <option value="RJ">RJ</option>
              <option value="PB">PB</option>
            </select>
            <br>     <br>

            <div class="mb-3"  style="width: 30%" >
              <b>   <label for="data_nascimento" class="form-label">Data De Nascimento</label></b>
              <input type="date" name="data_nascimento" class="form-control" placeholder="Data de Nascimento:" value="<?php echo e(old('data_nascimento')); ?>">
            </div>
 
            
            <button type="submit" class="btn btn-primary">Cadastrar</button>   
            <a href="/" class="btn btn-success" role="button">Voltar</a>
            
          </form>
          
          <script src="js/script.js"></script>

        </body>
        </html>
        
        









<?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/clientes/create.blade.php ENDPATH**/ ?>