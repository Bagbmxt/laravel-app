  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 

 <a style="margin-left: 20px" href="/usuarios" class="btn btn-success">Voltar</a>
 <h1 style="color: blue" > Usuários Editar  </h1>
 
<div style="background-color: rgb(86, 102, 80)">
 <main class="container" style="margin-top:20px" >

  



<div class="container" style="margin-top: 100px;">
   
        <form method="post" action="<?php echo e(route('user.update', $user->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="mb-3">
              <label for="name" class="form-label">Nome</label>
              <input type="text" value="<?php echo e($user->name); ?>" class="form-control" name="name" id="name" aria-describedby="emailHelp">

            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control" id="email">
            </div>

            <div class="mb-3">
              <label for="email" class="form-label">SENHA</label>
              <input type="password" name="password" class="form-control" id="password">
            </div>

            <button type="submit" class="btn btn-primary">ATUALIZAR</button>
          </form>

    </main>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/user/edit.blade.php ENDPATH**/ ?>