  
<?php $__env->startSection('content'); ?>


  <?php echo $__env->yieldContent('body'); ?>

    <main class="container">
        <h1>Adicionar Produtos</h1>
        <form method="post" action="<?php echo e(route('produtos.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
              <label for="name" class="form-label">Titulo</label>
              <input type="text"  class="form-control" name="name" id="name" aria-describedby="emailHelp">

              <div class="mb-3">
                <label for="name" class="form-label">Descrição</label>
                <input type="text"  class="form-control" name="name" id="name" aria-describedby="emailHelp">
  
              </div>

              <div class="mb-3">
                <label for="name" class="form-label">Valor</label>
                <input type="text"  class="form-control" name="name" id="name" aria-describedby="emailHelp">
  
              </div>

            <button type="submit" class="btn btn-primary">ADICIONAR</button>
          </form>
    </main>

    <?php $__env->stopSection(); ?>












<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-app\resources\views/produtos/create.blade.php ENDPATH**/ ?>