  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 


    <main class="container" style="margin-top:20px ">
   
        <a  type="button" href="<?php echo e(route('produtos.create')); ?>" class="btn btn-primary" > NOVO Produto</a>
        <a style="margin-left: 20px" href="/" class="btn btn-success">Voltar</a> 
      
    
      <div class="container" style="margin-top: 100px;">
      <h1 style="color: blue" > produtos Início  </h1>

        <table class="table" >
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Codigo</th>
                <th scope="col">Descrição</th>
                 <th scope="col">Preço</th>
                <th scope="col">Imposto</th>
                <th scope="col">Ver</th>
                <th scope="col">Editar</th>
                 <th scope="col">Deletar</th>
              </tr>
            </thead>
            <tbody>
        <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($produto->id); ?></th>
                <td><?php echo e($produto->codigo); ?></td>
                <td><?php echo e($produto->descricao); ?></td>
                <td><?php echo e($produto->preco); ?></td>
                <td><?php echo e($produto->imposto); ?></td>

                <td>
                    <a type="button" href="<?php echo e(route('produtos.show', $clientes->id)); ?>" class="btn btn-success">VER </a>
                </td>
                <td>
                    <a type="button" href="<?php echo e(route('produtos.edit', $produto->id)); ?>" class="btn btn-warning">EDITAR </a>
                </td>
                <td>
            <form action="<?php echo e(route('produtos.destroy', $produto->id)); ?>" method="post">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit"  class="btn btn-danger">DELETAR </a>
            </form>
                </td>
              </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
    </main>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/produtos/index.blade.php ENDPATH**/ ?>