  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 

 <main class="container" style="margin-top:20px ">
   
  <a  type="button" href="<?php echo e(route('user.create')); ?>" class="btn btn-primary" > NOVO USUARIO</a>
  <a style="margin-left: 20px" href="/usuarios" class="btn btn-success">Voltar</a> 


<div class="container" style="margin-top: 100px;">
<h1 style="color: blue" > Usuários Visualizar  </h1>

        <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Email</th>

              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row"><?php echo e($user->id); ?></th>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
              </tr>
            </tbody>
          </table>
        </div>
      
    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/user/show.blade.php ENDPATH**/ ?>