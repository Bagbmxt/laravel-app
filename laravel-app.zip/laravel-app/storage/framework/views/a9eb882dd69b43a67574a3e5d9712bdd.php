<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crud</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    <main class="container">
        <h1>Index</h1>
        <a type="button" href="<?php echo e(route('produtos.create')); ?>" class="btn btn-primary">
            NOVO PRODUTO
        </a>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Titulo</th>
                <th scope="col">Descriçao</th>
                <th scope="col">Valor</th>
                <th scope="col">Botao</th>
                <th scope="col">Editar</th>
                 <th scope="col">Deletar</th>
              </tr>
            </thead>
            <tbody>
        <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produtos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($produtos->id); ?></th>
                <td><?php echo e($produtos->alimentos); ?></td>
                <td><?php echo e($produtos->descricao); ?></td>
                <td><?php echo e($produtos->valor); ?></td>
                <td>
                 <a type="button" href="<?php echo e(route('produtos.show', $produtos->id)); ?>" class="btn btn-success">VER </a>
                </td>
                <td>
                    <a type="button" href="<?php echo e(route('produtos.edit', $produtos->id)); ?>" class="btn btn-warning">EDITAR </a>
                </td>
                <td>
            <form action="<?php echo e(route('produtos.destroy', $produtos->id)); ?>" method="post">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit"  class="btn btn-danger">DELETAR </a> 
            </form>
                </td>
              </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
<?php /**PATH C:\laragon\www\laravel-app\resources\views/produtos/index.blade.php ENDPATH**/ ?>