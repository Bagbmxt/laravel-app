  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 

 <main class="container" style="margin-top:20px ">
   
  <a  type="button" href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary" > NOVO Cliente</a>
  <a style="margin-left: 20px" href="/clientes" class="btn btn-success">Voltar</a> 


<div class="container" style="margin-top: 100px;">
<div class="cor" style="color: blue" > Clientes Visualizar  

        <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">CodigoCliente</th>
                <th scope="col">nome</th>
                <th scope="col">pessoa</th>
                <th scope="col">cnpj</th>
                <th scope="col">estado</th>
                <th scope="col">DataNascimento</th>

              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row"><?php echo e($cliente->id); ?></th>
                <td><?php echo e($cliente->codigocliente); ?></td>
                <td><?php echo e($cliente->nome); ?></td>
                <td><?php echo e($cliente->pessoa); ?></td>
                <td><?php echo e($cliente->cnpj); ?></td>
                <td><?php echo e($cliente->estado); ?></td>
                <td><?php echo e($cliente->data_nascimento); ?></td> 
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/clientes/show.blade.php ENDPATH**/ ?>