<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    
   
    <title>Clientes Início</title>
</head>

<body class="body-clientes-index">
  <header>
      <nav class="nav-bar">
          <div class="logo">
              <h1>Logo</h1>
          </div>
          <div class="nav-list">
              <ul>
                  <li class="nav-item"><a href="clientes/create" class="nav-link">Novo Cliente</a></li>
                  <li class="nav-item"><a href="clientes" class="nav-link">Listar Clientes</a></li>
                  <li class="nav-item"><a href="/" class="nav-link"> Home</a></li>
              </ul>
          </div>
          <div class="login-button">
              <button><a href="#">Entrar</a></button>
          </div>

          <div class="mobile-menu-icon">
              <button onclick="menuShow()"><img class="icon" src="img/menu_white_36dp.svg" alt=""></button>
          </div>
      </nav>
      <div class="mobile-menu">
          <ul>
            <li class="nav-item"><a href="clientes/create" class="nav-link">Novo Cliente</a></li>
            <li class="nav-item"><a href="clientes" class="nav-link">Listar Clientes</a></li>
            <li class="nav-item"><a href="/" class="nav-link"> Home</a></li>
          </ul>

          <div class="login-button">
              <button><a href="#">Entrar</a></button>
          </div>
      </div>
  </header>




   
  <a  type="button" href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary" > NOVO Cliente</a>
  <a style="margin-left: 20px" href="/clientes" class="btn btn-success">Voltar</a> 




        <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">CodigoCliente</th>
                <th scope="col">nome</th>
                <th scope="col">pessoa</th>
                <th scope="col">cnpj</th>
                <th scope="col">estado</th>
                <th scope="col">DataNascimento</th>

              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row"><?php echo e($cliente->id); ?></th>
                <td><?php echo e($cliente->codigocliente); ?></td>
                <td><?php echo e($cliente->nome); ?></td>
                <td><?php echo e($cliente->pessoa); ?></td>
                <td><?php echo e($cliente->cnpj); ?></td>
                <td><?php echo e($cliente->estado); ?></td>
                <td><?php echo e($cliente->data_nascimento); ?></td> 
              </tr>
            </tbody>
          </table>
        </div>
    
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <script src="js/script.js"></script>

      </body>
      </html>
      
      
<?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/clientes/show.blade.php ENDPATH**/ ?>