  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 


 <h1 style="color: rgb(16, 16, 17)" > Clientes Editar  </h1>
 <a style="margin-left: 20px" href="/produtos" class="btn btn-success">Voltar</a>
<div style="background-color: rgb(86, 102, 80)">
 <main class="container" style="margin-top:20px" >

  



<div class="container" style="margin-top: 100px;">
     
        <form method="post" action="<?php echo e(route('produtos.update', $produtos->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="mb-3">
              <b><label for="codigo" class="form-label">Codigo do Produto</label></b>
              <input type="number" value="<?php echo e($produtos->codigo); ?>" class="form-control" name="codigo" placeholder="Codigo">

            </div>
            <div class="mb-3">
              <label for="descricao" class="form-label">Descriçao</label>
              <input type="text" value="<?php echo e($produtos->descricao); ?>" class="form-control"  name="descricao" placeholder="Descrição">
            </div>

            <div class="mb-3">
              <label for="preco" class="form-label">Preço</label>
              <input type="number" step="0.010" value="<?php echo e($produtos->preco); ?>" class="form-control" name="preco" placeholder="Valor">
            </div>

            <div class="mb-3">
              <label for="name" class="form-label">Imposto</label>
              <input type="number" step="0.010" value="<?php echo e($produtos->imposto); ?>" class="form-control" name="imposto" placeholder="Imposto" >
            </div>
    
            <button type="submit" class="btn btn-primary">ATUALIZAR</button>
       
            
          </form>

    </main>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/produtos/edit.blade.php ENDPATH**/ ?>