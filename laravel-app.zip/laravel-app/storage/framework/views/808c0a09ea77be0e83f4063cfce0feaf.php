
  
<?php $__env->startSection('content'); ?>


 <?php echo $__env->yieldContent('body'); ?> 


<h1 style="color: black">Cliente: </h1>  <h1 style="color: rgb(129, 15, 15)"> <?php echo e($cliente->nome); ?> </h1>

<main class="container" style="margin-top:20px ">

    
<a  type="button" href="<?php echo e(route('produtos.create', $cliente->id)); ?>" class="btn btn-primary" > NOVO PRODUTO</a>

<a style="margin-left: 20px" href="/clientes" class="btn btn-success">Voltar</a> 






<table class="table" >
    <thead>
      <tr>
        <th scope="col">Codigo</th>
        <th scope="col">Descrição</th>
        <th scope="col">Preço</th>
        <th scope="col">Imposto</th>
        <th scope="col">Editar</th>
        <th scope="col">Excluir</th>

    </tr>
</thead>
<tbody>
<?php $__currentLoopData = $produto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produtos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($produtos->codigo); ?></td>
    <td><?php echo e($produtos->descricao); ?></td>
    <td><?php echo e($produtos->preco); ?></td>
    <td><?php echo e($produtos->imposto); ?></td>

     <td>
        <a type="button" href="<?php echo e(route('produtos.edit', ['clientes' => $cliente->id, 'id' => $produtos->id, 'id'])); ?>" class="btn btn-warning">EDITAR </a>
    </td> 
    
    <td>
    <form action="<?php echo e(route('produtos.destroy', $produtos->id)); ?>" method="post">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
        <button type="submit"  class="btn btn-danger">DELETAR </a>
    </form>
</td> 
  
</tr> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</main>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainpuro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/clientes/produtos/index.blade.php ENDPATH**/ ?>