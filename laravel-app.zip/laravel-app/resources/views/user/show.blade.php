@extends('layout.mainpuro')
  
@section('content')


 @yield('body') 

 <main class="container" style="margin-top:20px ">
   
  <a  type="button" href="{{route('user.create')}}" class="btn btn-primary" > NOVO USUARIO</a>
  <a style="margin-left: 20px" href="/usuarios" class="btn btn-success">Voltar</a> 


<div class="container" style="margin-top: 100px;">
<h1 style="color: blue" > Usuários Visualizar  </h1>

        <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Email</th>

              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">{{$user->id}}</th>
                <td>{{$user->name}}</td>
                <td>{{$user->email}}</td>
              </tr>
            </tbody>
          </table>
        </div>
      
    </main>

@endsection