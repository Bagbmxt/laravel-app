@extends('layout.mainpuro')
  
@section('content')


 @yield('body') 


    <main class="container" style="margin-top:20px ">
   
        <a  type="button" href="{{route('user.create')}}" class="btn btn-primary" > NOVO USUARIO</a>
        <a style="margin-left: 20px" href="/" class="btn btn-success">Voltar</a> 
      
    
      <div class="container" style="margin-top: 100px;">
      <h1 style="color: blue" > Usuários Início  </h1>

        <table class="table" >
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Email</th>
                <th scope="col">Botao</th>
                <th scope="col">Editar</th>
                 <th scope="col">Deletar</th>
              </tr>
            </thead>
            <tbody>
        @foreach ($usuarios as $user )
              <tr>
                <th scope="row">{{$user->id}}</th>
                <td>{{$user->name}}</td>
                <td>{{$user->email}}</td>
                <td>
                    <a type="button" href="{{route('user.show', $user->id)}}" class="btn btn-success">VER </a>
                </td>
                <td>
                    <a type="button" href="{{route('user.edit', $user->id)}}" class="btn btn-warning">EDITAR </a>
                </td>
                <td>
            <form action="{{route('user.destroy', $user->id)}}" method="post">
                @method('delete')
                @csrf
                <button type="submit"  class="btn btn-danger">DELETAR </a>
            </form>
                </td>
              </tr>

        @endforeach
            </tbody>
          </table>
        </div>
    </main>

    @endsection