@extends('layout.mainpuro')
  
@section('content')


 @yield('body') 

 <a style="margin-left: 20px" href="/usuarios" class="btn btn-success">Voltar</a>
 <h1 style="color: blue" > Usuários Editar  </h1>
 
<div style="background-color: rgb(86, 102, 80)">
 <main class="container" style="margin-top:20px" >

  



<div class="container" style="margin-top: 100px;">
   
        <form method="post" action="{{route('user.update', $user->id)}}">
            @csrf
            @method('put')
            <div class="mb-3">
              <label for="name" class="form-label">Nome</label>
              <input type="text" value="{{$user->name}}" class="form-control" name="name" id="name" aria-describedby="emailHelp">

            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input type="email" name="email" value="{{$user->email}}" class="form-control" id="email">
            </div>

            <div class="mb-3">
              <label for="email" class="form-label">SENHA</label>
              <input type="password" name="password" class="form-control" id="password">
            </div>

            <button type="submit" class="btn btn-primary">ATUALIZAR</button>
          </form>

    </main>
  </div>
</div>
@endsection
