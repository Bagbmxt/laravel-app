@extends('layout.main')
  
@section('conteudo')


 @yield('body') 

 <a style="margin-left: 20px" href="/produtos" class="btn btn-success">Voltar</a>
 <h1 style="color: rgb(0, 0, 0)" >Produtos Editar  </h1>
 
<div style="background-color: rgb(86, 102, 80)">
 <main class="container" style="margin-top:20px" >

  



<div class="container" style="margin-top: 100px;">
        <h1>Atualizar Produto</h1>
        <form method="post" action="{{route('produtos.update', $produto->id)}}">
            @csrf
            @method('PUT')

            <div class="mb-3" style="width: 7%">
              <label for="codigo"  class="form-label">Codigo</label>
              <input type="text"  class="form-control" value="{{ $produto->codigo}}"   name="codigo" placeholder="Codigo :">
            </div>
          
            <div class="mb-3" style="width: 50%">
              <label for="descricao" class="form-label">Descrição</label>
              <input type="text"  class="form-control" value="{{ $produto->descricao}}" name="descricao"  placeholder="Descricao:">
            </div>
               
            <div class="mb-3"style="width: 7%">
              <label for="preco" class="form-label">Preço</label>
              <input type="text"  class="form-control" value="{{ $produto->preco}}" name="preco" placeholder="Preço:">
            </div>
          
            <div class="mb-3"style="width: 8%">
              <label for="imposto" class="form-label">Imposto</label>
              <input type="text" class="form-control" value="{{ $produto->imposto}}" name="imposto" placeholder="Imposto :">
            </div>  
          
              <button type="submit" class="btn btn-primary">Cadastrar</button>   
              <a href="/" class="btn btn-success" role="button">Voltar</a>
          </form>

    </main>
  </div>
</div>
@endsection
