@extends('layout.mainpuro')
  
@section('content')


 @yield('body') 


<h1 style="color: black">Cliente: </h1>  <h1 style="color: rgb(129, 15, 15)"> {{ $cliente->nome }} </h1>

<main class="container" style="margin-top:20px ">

    
<a  type="button" href="{{ route('produtos.create', $cliente->id) }}" class="btn btn-primary" > NOVO PRODUTO</a>

<a style="margin-left: 20px" href="/clientes" class="btn btn-success">Voltar</a> 



{{-- <form action="{{ route('clientes.index')}}">
    <input type="text" name="search" placeholder="Pesquisar">
    <button>Pesquisar</button>
</form> --}}


<table class="table" >
    <thead>
      <tr>
        <th scope="col">Codigo</th>
        <th scope="col">Descrição</th>
        <th scope="col">Preço</th>
        <th scope="col">Imposto</th>
        <th scope="col">Editar</th>
        <th scope="col">Excluir</th>

    </tr>
</thead>
<tbody>
@foreach ($produto as $produtos)
<tr>
    <td>{{$produtos->codigo}}</td>
    <td>{{$produtos->descricao}}</td>
    <td>{{$produtos->preco}}</td>
    <td>{{$produtos->imposto}}</td>
{{-- <td>
    <a type="button" href="{{route('produtos.edit', $produtos->id)}}" class="btn btn-warning">EDITAR </a>
</td> --}}
     <td>
        <a type="button" href="{{route('produtos.edit', ['clientes' => $cliente->id, 'id' => $produtos->id, 'id']) }}" class="btn btn-warning">EDITAR </a>
    </td> 
    
    <td>
    <form action="{{route('produtos.destroy', $produtos->id)}}" method="post">
        @method('delete')
        @csrf
        <button type="submit"  class="btn btn-danger">DELETAR </a>
    </form>
</td> 
  
</tr> 
@endforeach
</tbody>
</table>
</div>
</main>





@endsection
