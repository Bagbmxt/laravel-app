@extends('layout.mainpuro')
  
@section('content')


 @yield('body') 


 <main class="container" >
    <h1>Adicionar Produto</h1>
    <form action="{{ route('produtos.store', $cliente->id) }}" method="post">
        @csrf
        <div class="mb-3" style="width: 7%">
            <label for="codigo"  class="form-label">Codigo</label>
            <input type="text"  class="form-control"  name="codigo" placeholder="Codigo :">
          </div>
        
          <div class="mb-3" style="width: 50%">
            <label for="descricao" class="form-label">Descrição</label>
            <input type="text"  class="form-control" name="descricao"  placeholder="Descricao:">
          </div>
             
          <div class="mb-3"style="width: 7%">
            <label for="preco" class="form-label">Preço</label>
            <input type="text"  class="form-control" name="preco" placeholder="Preço:">
          </div>
        
          <div class="mb-3"style="width: 8%">
            <label for="imposto" class="form-label">Imposto</label>
            <input type="text" class="form-control" name="imposto" placeholder="Imposto :">
          </div>  
        
            <button type="submit" class="btn btn-primary">Cadastrar</button>   
            <a href="/" class="btn btn-success" role="button">Voltar</a>
        {{-- 
        <input type="text" name="name" value="{{ old('name')}}" placeholder="Nome:">    
        <input type="email" name="email" value="{{ old('email')}}" placeholder="E-mail:">    
        <input type="password" name="password" placeholder="Senha:">     --}}
        
        </form>  
    </main>
 
    @endsection 
 
 



