@extends('layout.mainpuro')
  
@section('content')


 @yield('body') 

 <main class="container" style="margin-top:20px ">
   
  <a  type="button" href="{{route('clientes.create')}}" class="btn btn-primary" > NOVO Cliente</a>
  <a style="margin-left: 20px" href="/clientes" class="btn btn-success">Voltar</a> 


<div class="container" style="margin-top: 100px;">
<div class="cor" style="color: blue" > Clientes Visualizar  

        <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">CodigoCliente</th>
                <th scope="col">nome</th>
                <th scope="col">pessoa</th>
                <th scope="col">cnpj</th>
                <th scope="col">estado</th>
                <th scope="col">DataNascimento</th>

              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">{{$cliente->id}}</th>
                <td>{{$cliente->codigocliente}}</td>
                <td>{{$cliente->nome}}</td>
                <td>{{$cliente->pessoa}}</td>
                <td>{{$cliente->cnpj}}</td>
                <td>{{$cliente->estado}}</td>
                <td>{{$cliente->data_nascimento}}</td> 
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
@endsection