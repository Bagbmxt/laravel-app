<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Clientes Início</title>
</head>

<body class="body-clientes-index">
    <header>
        <nav class="nav-bar">
            <div class="logo">
                <h1>Logo</h1>
            </div>
            <div class="nav-list">
                <ul>
                    <li class="nav-item"><a href="clientes/create" class="nav-link">Novo Cliente</a></li>
                    <li class="nav-item"><a href="clientes" class="nav-link">Listar Clientes</a></li>
                    <li class="nav-item"><a href="/" class="nav-link"> Home</a></li>
                </ul>
            </div>
            <div class="login-button">
                <button><a href="#">Entrar</a></button>
            </div>

            <div class="mobile-menu-icon">
                <button onclick="menuShow()"><img class="icon" src="img/menu_white_36dp.svg" alt=""></button>
            </div>
        </nav>
        <div class="mobile-menu">
            <ul>
              <li class="nav-item"><a href="clientes/create" class="nav-link">Novo Cliente</a></li>
              <li class="nav-item"><a href="clientes" class="nav-link">Listar Clientes</a></li>
              <li class="nav-item"><a href="/" class="nav-link"> Home</a></li>
            </ul>

            <div class="login-button">
                <button><a href="#">Entrar</a></button>
            </div>
        </div>
    </header>




      <div class="fonteadd" >  <a href="{{route('clientes.create')}}"><i class="fa-sharp fa-solid fa-person-circle-plus fa-2xl" style="color: #000000; "></i></a></div> 

      <div class="fontevoltar">  <a href="/" class="btn btn-success"> <i class="fa-solid fa-backward"></i> </a></div> 
      
          <div class="search">
            <form action="{{ route('clientes.index')}}">
              <input type="text" name="search" placeholder="Pesquisar">
              <button>Pesquisar</button>
            </form>
          </div>


 

    <div class="table-responsive">
      <table class="table" >
        <thead class="thead-dark">
            <tr>
              <th scope="col" >ID</th>
              <th scope="col">CodigoCliente</th>
              <th scope="col">nome</th>
               <th scope="col">pessoa</th>
              <th scope="col">cnpj</th>
              <th scope="col">estado</th>
              <th scope="col">DataNascimento</th> 
              <th scope="col">Produtos</th>
              <th scope="col">Ver</th>
              <th scope="col">Editar</th>
               <th scope="col">Deletar</th>
            </tr>
          </thead>
          <tbody>
      @foreach ($clientes as $cliente)
        <tr>
              <th scope="row">{{$cliente->id}}</th>
              <td>{{$cliente->codigocliente}}</td>
              <td>{{$cliente->nome}}</td>
              <td>{{$cliente->pessoa}}</td>
              <td>{{$cliente->cnpj}}</td>
              <td>{{$cliente->estado}}</td>
              <td>{{$cliente->data_nascimento}}</td> 

                  <td>
                    <a type="button" href="{{ route ('produtos.index', $cliente->id)}}" class="btn btn-success">Produto ({{ $cliente->produtos->count() }}) </a>
                  </td>
                  
                <td>
                    <a type="button" href="{{route('clientes.show', $cliente->id)}}" class="btn btn-success">VER </a>
                </td>
                    <td>
                        <a type="button" href="{{route('clientes.edit', $cliente->id)}}" class="btn btn-warning">EDITAR </a>
                    </td>
                          <td>
                              <form action="{{route('clientes.destroy', $cliente->id)}}" method="post">
                                  @method('delete')
                                  @csrf
                                  <button type="submit"  class="btn btn-danger">DELETAR </a>
                              </form>
                          </td>
        </tr>    

      @endforeach
          </tbody>
          
</table>
</div>

        <div class="py-4" style="align-items: center">
          {{ $clientes->appends(['search' => request()->get('search', '') ])->links() }}
        </div>
    
    <script src="js/script.js"></script>

</body>
</html>











