@extends('layout.mainpuro')
  
@section('content')


 @yield('body') 


    <main class="container" style="margin-top:20px ">
   
        <a  type="button" href="{{route('clientes.create')}}" class="btn btn-primary" > NOVO CLIENTE</a>
        <a style="margin-left: 20px" href="/" class="btn btn-success">Voltar</a> 
      
    
      <div class="container" style="margin-top: 100px;">
      <h1 style="color: blue" > Clientes Início  </h1>

        <table class="table" >
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">CodigoCliente</th>
                <th scope="col">nome</th>
                 <th scope="col">pessoa</th>
                <th scope="col">cnpj</th>
                <th scope="col">estado</th>
                <th scope="col">DataNascimento</th> 
                <th scope="col">Produtos</th>
                <th scope="col">Ver</th>
                <th scope="col">Editar</th>
                 <th scope="col">Deletar</th>
              </tr>
            </thead>
            <tbody>
        @foreach ($clientes as $cliente)
              <tr>
                <th scope="row">{{$cliente->id}}</th>
                <td>{{$cliente->codigocliente}}</td>
                <td>{{$cliente->nome}}</td>
                <td>{{$cliente->pessoa}}</td>
                <td>{{$cliente->cnpj}}</td>
                <td>{{$cliente->estado}}</td>
                <td>{{$cliente->data_nascimento}}</td> 

              <td>
                <a type="button" href="{{ route ('produtos.index', $cliente->id)}}" class="btn btn-success">PRODUTOS </a>
              </td>
              
                <td>
                    <a type="button" href="{{route('clientes.show', $cliente->id)}}" class="btn btn-success">VER </a>
                </td>
                <td>
                    <a type="button" href="{{route('clientes.edit', $cliente->id)}}" class="btn btn-warning">EDITAR </a>
                </td>
                <td>
            <form action="{{route('clientes.destroy', $cliente->id)}}" method="post">
                @method('delete')
                @csrf
                <button type="submit"  class="btn btn-danger">DELETAR </a>
            </form>
                </td>
              </tr>

        @endforeach
            </tbody>
          </table>
        </div>
    </main>

    @endsection