@extends('layout.mainpuro')
  
@section('content')


 @yield('body') 

 <a style="margin-left: 20px" href="/clientes" class="btn btn-success">Voltar</a>
 <h1 style="color: rgb(0, 0, 0)" > Clientes Editar  </h1>
 
<div style="background-color: rgb(86, 102, 80)">
 <main class="container" style="margin-top:20px" >

  



<div class="container" style="margin-top: 100px;">
   
        <form method="post" action="{{route('clientes.update', $cliente->id)}}">
            @csrf
            @method('put')

            <div class="mb-3">
              <label for="codigocliente" class="form-label">Codigocliente</label>
              <input type="number"  class="form-control" value="{{ $cliente->codigocliente}}" name="codigocliente" placeholder="Codigo CLiente">
            </div>

            <div class="mb-3">
              <label for="nome" class="form-label">Nome</label>
              <input type="text" name="nome" class="form-control" value="{{ $cliente->nome}}" placeholder="Nome:">
            </div>

            <input type="radio" id="pessoa" name="pessoa" value="J">
            <label for="pessoa">fisico</label><br>

            <input type="radio" id="pessoa" name="pessoa" value="F">
            <label for="pessoa">Juridico</label><br>

            <input type="radio" id="pessoa" name="pessoa" value="O">
            <label for="pessoa">Outros</label>
            
            <div class="mb-3">
              <label for="cnpj" class="form-label">CNPJ</label>
              <input type="text" name="cnpj" class="form-control" value="{{ $cliente->cnpj}}" placeholder="Cnpj:">
            </div>

            <div class="mb-3">
              <label for="estado" class="form-label">Estado</label>
              <input type="text" name="estado" class="form-control" value="{{ $cliente->estado}}" placeholder="Estado:">
            </div>

            <div class="mb-3">
              <label for="data_nascimento" class="form-label">Data De Nascimento</label>
              <input type="date" name="data_nascimento" class="form-control" value="{{ $cliente->data_nascimento}}" placeholder="Data De nascimento:">
            </div>
 

            <button type="submit" class="btn btn-primary">ATUALIZAR</button>
          </form>

    </main>
  </div>
</div>
@endsection
